# Site Hind Hachmi — publication gratuite

Le fichier index.html contient le site complet : HTML, styles, illustration et interactions. Aucun outil à installer. Les boutons de réservation ouvrent Doctolib.

## GitHub Pages
1. Créez un compte sur https://github.com si nécessaire.
2. Créez un dépôt PUBLIC nommé hind-hachmi-kine. Activez Add README.
3. Décompressez ce ZIP sur votre ordinateur.
4. Dans le dépôt : Add file > Upload files. Déposez index.html et, si visible, .nojekyll À LA RACINE du dépôt. Ne téléversez pas le ZIP lui-même. Validez avec Commit changes. Ce README peut servir de guide sur votre ordinateur.
5. Settings > Pages > Source : Deploy from a branch > Branch : main > Folder : /(root) > Save.
6. Attendez la publication, puis cliquez sur Visit site dans Settings > Pages.

Votre adresse sera https://VOTRE-PSEUDO.github.io/hind-hachmi-kine/ (VOTRE-PSEUDO est à remplacer par votre nom de compte GitHub).
Le dépôt et le site seront publics. Aucun nom de domaine payant n’est nécessaire.

## Google Search Console
1. Attendez que le site public fonctionne.
2. Ouvrez https://search.google.com/search-console
3. Ajoutez une propriété de type Préfixe de l’URL avec l’URL complète du site, y compris https:// et le / final.
4. Choisissez la validation par fichier HTML. Téléchargez le fichier de validation fourni par Google.
5. Ajoutez ce fichier dans votre dépôt, au même niveau que index.html, sans le modifier ni le renommer.
6. Attendez sa publication et vérifiez que l’adresse du fichier affichée par Google fonctionne.
7. Revenez dans Search Console et cliquez sur Valider. Conservez le fichier dans le dépôt.
8. Dans Inspection de l’URL, saisissez l’adresse de la page d’accueil puis demandez l’indexation si elle est disponible.

La validation confirme votre propriété ; elle ne garantit pas l’indexation ni une position dans les résultats de recherche.

## Modifier le site
Dans GitHub, ouvrez index.html puis l’icône crayon. Enregistrez avec Commit changes : GitHub Pages republiera le fichier.
Les coordonnées, les soins et le lien Doctolib peuvent être modifiés dans ce fichier.
